﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FrontToBackP314.DAL;
using FrontToBackP314.Models;
using FrontToBackP314.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FrontToBackP314.Controllers
{
    public class ProductController : Controller
    {
        private readonly AppDbContext _db;
        public ProductController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            ViewBag.ProductCount = _db.Products.Count();
            return View();
        }

        public IActionResult LoadMore(int skip)
        {
            IEnumerable<Product> model = _db.Products.Include(p => p.Category).Skip(skip).Take(8);
            return PartialView("_ProductPartial", model);
            #region OLD VERSION
            //return Json(_db.Products.Select(p=>new ProductVM { 
            //    Id=p.Id,
            //    Name=p.Name,
            //    Image=p.Image,
            //    Price=p.Price,
            //    Category=p.Category
            //}).Skip(8).Take(8));
            #endregion

        }

        public IActionResult Search(string search)
        {
            IEnumerable<Product> products = _db.Products.Where(p => p.Name.ToLower().Contains(search.ToLower()))
                .OrderByDescending(p=>p.Id).Take(10);
            return PartialView("_ProductSearch", products);
        }
    }
}